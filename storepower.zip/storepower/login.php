<?php  

	# Lendo o arquivo de usuarios
	$users =  file("modules/database/users.txt");

	# Recebendo os dados do formulario
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	
	$posicao = -1;
	# Percorrendo o arquivo de dados de usuarios
	foreach ($users as $k=>$user) {
		
		# Agora vamos percorrer cada usuário por vez, até encontrar o email digitado
		$u = explode(" - ", $user);

		# Variável de controle para verificar se o email existe ou não na base
		$encontrouEmail = false;

		if($u[1] == $email){
			$encontrouEmail = true;
			$posicao = $k;
			break; // Quebra do laço de repetição
		}
	}


	if(!$encontrouEmail){
		header("location: index.php?error=user_not_found");
	}else{
		
		# Encontrou alguem com o email enviado, então agora podemos ver se ele pode ou não acessar os modulos do sistema
		$usuario = explode(" - ", $users[$posicao]);

		# Verificando a senha do usuário
		if($pass != $usuario[2]){
			header("location: index.php?error=incorrect_date");		
		}else{

			session_start();

			$_SESSION['user'] = $usuario;

			header("location: index.php");
			//header("location: modules/dashboard/index.php");
		}
	}


	


?>