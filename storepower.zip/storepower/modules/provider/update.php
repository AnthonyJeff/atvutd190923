<?php

    
    # Ler o id recebido para ser editado
    $id = $_POST['id'];

    # Removendo o id do array POST
    unset($_POST['id']);

    # Transformando um array recebido em string
    $providerEdited = implode(" - ", $_POST).PHP_EOL;

    # Ler o arquivo de texto
    $provider = file("../database/provider.txt");
   
    # Excluindo o elemento antigo do array
    //unset($provider[$id]);

    # Colocando o produto editado no array novamente
    //array_unshift($provider, $providerEdited);
    $provider[$id] = $providerEdited;
    
    # Apagar o arquivo anterior
    unlink("../database/provider.txt");
    
    # Transformando um array em string
    $string = implode("", $provider);

    # Recria o arquivo
    $file = fopen("../database/provider.txt", "a+");

    # Escrever no arquivo
    fwrite($file, $string);

    # Fechando o arquivo
    fclose($file);
    
    # Redirecionamento
    header("location: http://localhost/project/modules/provider/index.php");
    

?>