<?php

	# Continuar cadastrando?
	$continue = (isset($_POST['continue'])) ? true  : false;

	# Verificando se é ou não pra continuar cadatsrando produtos..., pois se a opção estiver marcada, é necessário excluir do array POST
	if($continue){
		unset($_POST['continue']);
		$redir = 'http://localhost/project/modules/provider/insertForm.php';
	}else{
		$redir = 'http://localhost/project/modules/provider/index.php';		
	}

    # Transformando um array em string
    $string = implode(" - ", $_POST);
   
    # Cria o arquivo ou adiciona o proximo produto nele
    $file = fopen("../database/provider.txt", "a+");

    # Escrever no arquivo
    fwrite($file, $string.PHP_EOL);

    # Fechando o arquivo
    fclose($file);    

    # Redirecionamento
    header("location: $redir");

?>