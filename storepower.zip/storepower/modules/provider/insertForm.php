        <?php include_once '../layout/header.php';?>
        <div id="layoutSidenav">
            
            <!-- Menu Principal -->
            <?php include_once '../layout/menu.php';?>


            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4"> Cadastro de Fornecedores</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="http://localhost/project/modules/dashboard/index.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Cadastro de Fornecedores</li>
                        </ol>
                        <!-- <div class="card mb-4">
                            <div class="card-body">
                                DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the
                                <a target="_blank" href="https://datatables.net/">official DataTables documentation</a>
                                .
                            </div>
                        </div> -->
                        <div class="card mb-4 border-primary">
                            <div class="card-header bg-gradient bg-primary">
                                <i class="fas fa-table me-1"></i>
                                Cadastro de Fornecedores
                            </div>
                            <div class="card-body">
                                <div class="container">
                                    <div class="row">
                                        <div class="">
                                            <div class="p-5 mb-4 bg-body-tertiary rounded-3">
                                               
                                                                           
                                                    <form action="insert.php" method="POST">
                                                        <div class="row">

                                                            <div class="col-md-6">    
                                                                <div class="input-group mb-3">
                                                                    <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="lucide:boxes"></span></span>
                                                                    <input type="text" class="form-control" placeholder="NOME DO FORNECEDOR" name="nome">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">
                                                                <div class="input-group mb-3 col-6">
                                                                    <span class="input-group-text iconify" id="basic-addon1"><span class="iconify" data-icon="material-symbols:barcode"></span></span>
                                                                    <input type="text" class="form-control" placeholder="CNPJ DO FORNECEDOR" name="cnpj">
                                                                    <span class="iconify" ></span>
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">    
                                                                <div class="input-group mb-3">
                                                                    <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="healthicons:stock-out-negative"></span></span>
                                                                    <input type="email" class="form-control" placeholder="EMAIL DE CONTATO" name="estoque">
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="col-md-6">    
                                                                <div class="input-group mb-3">
                                                                    <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="solar:tag-price-bold"></span></span>
                                                                    <input type="text" class="form-control" placeholder="CONTATO"  name="preco">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">    
                                                                <div class="input-group mb-3">
                                                                    <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="material-symbols:image"></span></span>
                                                                    <input type="text" class="form-control" placeholder="LOGOMARCA" name="imagem">
                                                                </div>
                                                            </div>

                                                            <div class="col-md-6">  
                                                                <input type="checkbox" value="YES" name="continue"> Continuar Cadastrando? 
                                                            </div>

                                                            
                                                        </div>
                                                        <button type="submit" class="btn btn-outline-primary" type="button">Enviar Dados</button>
                                                    </form>
                                                   
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </main>
                <?php include_once '../layout/footer.php';?>
