<?php

# Incluindo a lista de produtos
$provider = file("../database/provider.txt");

?>
    <?php include_once '../layout/header.php';?>
    <div id="layoutSidenav">

        <!-- Menu Principal -->
        <?php include_once '../layout/menu.php';?>


        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                    <h1 class="mt-4"> Lista de Fornecedores</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item"><a href="http://localhost/project/modules/dashboard/index.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Lista de Produtos</li>
                    </ol>
                    <!-- <div class="card mb-4">
                            <div class="card-body">
                                DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the
                                <a target="_blank" href="https://datatables.net/">official DataTables documentation</a>
                                .
                            </div>
                        </div> -->
                    <div class="card mb-4 border-primary">
                        <div class="card-header bg-gradient bg-primary">
                            <i class="fas fa-table me-1"></i>
                            Lista de Forecedores
                        </div>
                        <div class="card-body">
                            <table id="datatablesSimple" class="table table-striped">
                                <thead>
                                    <tr class="text-center">
                                        <th>Nome</th>
                                        <th>CNPJ</th>
                                        <th>Email</th>
                                        <th>Contato</th>
                                        <th>Logomarca</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php foreach ($provider as $key => $prov) : ?>
                                        <?php $p = explode(" - ", $prov); ?>
                                        <tr>
                                            <td class="align-middle"><?= $p[0]; ?></td>
                                            <td class="align-middle"><?= $p[1]; ?></td>
                                            <td class="align-middle"><?= $p[2]; ?></td>
                                            <td class="align-middle"><?= $p[3]; ?></td>
                                            <td>
                                                <p class="text-center"><img src="<?=$p[4];?>" width="60" height="60"></p>
                                            </td>
                                            <td>
                                                <button id="tooltip" onclick="delete_reg('<?= $p[0]; ?>','<?= trim($p[4]); ?>','<?= $key;?>')" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#excluir"><span class="iconify" data-icon="bi:trash-fill"></span></button>
                                                <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editar-<?= $key; ?>"><span class="iconify" data-icon="ph:pencil-bold"></span></button>
                                                <button class="btn btn-sm btn-secondary"><span class="iconify" data-icon="gridicons:block"></span></button>

                                                <!-- Modal de edicao -->
                                                <div class="modal fade" id="editar-<?= $key; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header bg-warning bg-gradient">
                                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Editar Fornecedor</h1>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <form action="update.php" method="POST">
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-md-4 offset-md-4 p-4">
                                                                            <label class="text-center"> Foto Atual: </label><br>
                                                                            <img src="<?= $p[4]; ?>" class="img-fluid">
                                                                        </div>
                                                                        <div class="col-md-12">
                                                                            <div class="row">

                                                                                <div class="col-md-12">
                                                                                    <div class="input-group mb-3">
                                                                                        <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="lucide:boxes"></span></span>
                                                                                        <input type="text" value="<?= $p[0]; ?>" class="form-control" placeholder="NOME DO FORNECEDOR" name="nome">
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-md-12">
                                                                                    <div class="input-group mb-3 col-6">
                                                                                        <span class="input-group-text iconify" id="basic-addon1"><span class="iconify" data-icon="material-symbols:barcode"></span></span>
                                                                                        <input type="text" class="form-control" value="<?= $p[1]; ?>" placeholder="CNPJ DO FORNECEDOR" name="cnpj">
                                                                                        <span class="iconify"></span>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-md-12">
                                                                                    <div class="input-group mb-3">
                                                                                        <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="healthicons:stock-out-negative"></span></span>
                                                                                        <input type="email" class="form-control" value="<?= $p[2]; ?>" placeholder="EMAIL DE CONTATO" name="estoque">
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-md-12">
                                                                                    <div class="input-group mb-3">
                                                                                        <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="solar:tag-price-bold"></span></span>
                                                                                        <input type="text" class="form-control" value="<?= $p[3]; ?>" placeholder="CONTATO" name="preco">
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-md-12">
                                                                                    <div class="input-group mb-3">
                                                                                        <span class="input-group-text" id="basic-addon1"><span class="iconify" data-icon="material-symbols:image"></span></span>
                                                                                        <input type="text" class="form-control" value="<?= $p[4]; ?>" placeholder="LOGOMARCA" name="imagem">
                                                                                    </div>
                                                                                </div>



                                                                            </div>


                                                                        </div>
                                                                    </div>

                                                                    <!-- levando o id do produto -->
                                                                    <input type="hidden" name="id" value="<?= $key; ?>">
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Não, Cancelar</button>
                                                                    <button type="submit" class="btn btn-outline-success">Sim, continuar</button>
                                                                </div>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>

                                            </td>
                                        </tr>
                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
            <?php include_once '../layout/footer.php';?>
            
    <!-- Modal de Exclusao -->
    <div class="modal fade" id="excluir" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger bg-gradient font-color-white">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Excluir Fornecedor</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="delete.php" method="POST">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4"><img id="link"  class="img-fluid"></div>
                            <div class="col-md-8">
                                Tem certeza que deseja excluir o fornecedor <strong id="nome"></strong>?
                                Essa operação é irreversível.
                            </div>
                        </div>

                        <!-- levando o id do produto -->
                        <input type="hidden" name="id" id="del">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Não, Cancelar</button>
                        <button type="submit" class="btn btn-outline-success">Sim, continuar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>



    <script type="text/javascript">
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip()
        });

        /* Função JavaScript para excluir um registro */
        function delete_reg(nome, link, id) {
            console.log(link);
            $("#nome").html(nome);            
            document.getElementById("link").src=link;
            $('#idDel').val(id);
        }
    </script>

</body>

</html>