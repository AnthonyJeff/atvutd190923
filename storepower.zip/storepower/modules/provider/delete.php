<?php

    
    # Ler o id recebido para ser exluido
    $id = $_POST['id'];

    # Ler o arquivo de texto
    $provider = file("../database/provider.txt");
   
    # Excluindo o elemento do array
    unset($provider[$id]);
    
    # Apagar o arquivo anterior
    unlink("../database/provider.txt");
    
    # Transformando um array em string
    $string = implode("", $provider);

    # Recria o arquivo
    $file = fopen("../database/provider.txt", "a+");

    # Escrever no arquivo
    fwrite($file, $string);

    # Fechando o arquivo
    fclose($file);
    
    # Redirecionamento
    header("location: http://localhost/project/modules/provider/index.php");
    






?>