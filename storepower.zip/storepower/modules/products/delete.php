<?php

    
    # Ler o id recebido para ser exluido
    $id = $_POST['id'];

    # Ler o arquivo de texto
    $products = file("../database/products.txt");
   
    # Excluindo o elemento do array
    unset($products[$id]);
    
    # Apagar o arquivo anterior
    unlink("../database/products.txt");
    
    # Transformando um array em string
    $string = implode("", $products);

    # Recria o arquivo
    $file = fopen("../database/products.txt", "a+");

    # Escrever no arquivo
    fwrite($file, $string);

    # Fechando o arquivo
    fclose($file);
    
    # Redirecionamento
    header("location: http://localhost/project/modules/products/index.php");
    






?>