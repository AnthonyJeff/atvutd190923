<?php

    
    # Ler o id recebido para ser editado
    $id = $_POST['id'];

    # Removendo o id do array POST
    unset($_POST['id']);

    # Transformando um array recebido em string
    $productEdited = implode(" - ", $_POST).PHP_EOL;

    # Ler o arquivo de texto
    $products = file("../database/products.txt");
   
    # Excluindo o elemento antigo do array
    //unset($products[$id]);

    # Colocando o produto editado no array novamente
    //array_unshift($products, $productEdited);
    $products[$id] = $productEdited;
    
    # Apagar o arquivo anterior
    unlink("../database/products.txt");
    
    # Transformando um array em string
    $string = implode("", $products);

    # Recria o arquivo
    $file = fopen("../database/products.txt", "a+");

    # Escrever no arquivo
    fwrite($file, $string);

    # Fechando o arquivo
    fclose($file);
    
    # Redirecionamento
    header("location: http://localhost/project/modules/products/index.php");
    

?>