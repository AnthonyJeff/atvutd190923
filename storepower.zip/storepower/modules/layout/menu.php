<?php if(true): ?>
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">INFORMATIVOS</div>
                    <a class="nav-link" href="<?=$urlBase;?>modules/dashboard/index.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>
                    <div class="sb-sidenav-menu-heading">MÓDULOS DO SISTEMA</div>
                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fas fa-boxes"></i></div>
                        Produtos
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="<?=$urlBase;?>modules/products/index.php">Lista de Produtos</a>
                            <a class="nav-link" href="<?=$urlBase;?>modules/products/insertForm.php">Cadastrar Produto</a>
                        </nav>
                    </div>

                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#fornecedores" aria-expanded="false" aria-controls="fornecedores">
                        <div class="sb-nav-link-icon"><i class="fas fa-truck"></i></div>
                        Fornecedores
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="fornecedores" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="<?=$urlBase;?>modules/provider/index.php">Lista de Fornecedores</a>
                            <a class="nav-link" href="<?=$urlBase;?>modules/provider/insertForm.php">Cadastrar Fornecedor</a>
                        </nav>
                    </div>

                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#clientes" aria-expanded="false" aria-controls="clientes">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        Clientes
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="clientes" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="<?=$urlBase;?>modules/clients/index.php">Lista de Clientes</a>
                            <a class="nav-link" href="<?=$urlBase;?>modules/clients/insertForm.php">Cadastrar Cliente</a>
                        </nav>
                    </div>

                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#vendas" aria-expanded="false" aria-controls="vendas">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        Vendas
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="vendas" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="<?=$urlBase;?>modules/clients/index.php">Lista de Vendas</a>
                            <a class="nav-link" href="<?=$urlBase;?>modules/clients/insertForm.php">Cadastrar Venda</a>
                        </nav>
                    </div>

                    
                    <div class="sb-sidenav-menu-heading">OUTRAS AÇÕES</div>
                    
                    <a class="nav-link" href="#">
                        <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                        Perfil
                    </a>
                    <a class="nav-link" href="<?=$urlBase;?>/logout.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-power-off"></i></div>
                        Sair do Sistema
                    </a>
                    
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Bem vindo, <?=$_SESSION['user'][0];?></div>
                <?=date("d/m/Y H:i:s");?>
            </div>
        </nav>
    </div>
<?php else: ?>
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    
                    <div class="sb-sidenav-menu-heading">MÓDULOS DO SISTEMA</div>
                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                        <div class="sb-nav-link-icon"><i class="fas fa-boxes"></i></div>
                        Produtos
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="<?=$urlBase;?>modules/products/index.php">Lista de Produtos</a>
                            <a class="nav-link" href="<?=$urlBase;?>modules/products/insertForm.php">Cadastrar Produto</a>
                        </nav>
                    </div>                  

                    

                    <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#vendas" aria-expanded="false" aria-controls="vendas">
                        <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                        Vendas
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="vendas" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        <nav class="sb-sidenav-menu-nested nav">
                            <a class="nav-link" href="<?=$urlBase;?>modules/clients/index.php">Lista de Vendas</a>
                            <a class="nav-link" href="<?=$urlBase;?>modules/clients/insertForm.php">Cadastrar Venda</a>
                        </nav>
                    </div>

                    
                    <div class="sb-sidenav-menu-heading">OUTRAS AÇÕES</div>
                    
                    <a class="nav-link" href="#">
                        <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                        Perfil
                    </a>
                    <a class="nav-link" href="<?=$urlBase;?>index.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-power-off"></i></div>
                        Sair do Sistema
                    </a>
                    
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Logado as:</div>
                <?=date("d/m/Y H:i:s");?>
            </div>
        </nav>
    </div>
<?php endif; ?>
