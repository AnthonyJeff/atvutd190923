<?php

    # Biblioteca CRUD

    // INSERT INTO `$table` ($campos) VALUES ($values)
    function insert($table, $data = array()){
        # 1º Parte
        $query = "INSERT INTO `$table` ";
        
        # 2º Parte
        $fields = implode('`, `', array_keys($data) );

        $query .= "(`$fields`) ";
        
        # 3º Parte
        $values = implode("', '", $data );
        $query .= "VALUES ('$values'); ";

        //echo $query;
        global $conn;
        
        $result = mysqli_query($conn, $query) or die(mysqli_error($conn));
    
        return $result;

    }



?>