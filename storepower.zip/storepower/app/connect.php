<?php

    # mysql -u root -p password
    # USE DATABASE;

    $host     = "localhost";
    $user     = "root";
    $pass     = "";
    $database = "database_name";

    $conn = mysqli_connect($host, $user, $pass, $database) or die(mysqli_connect_error());    

?>