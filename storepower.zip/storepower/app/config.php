<?php

    session_start();

    $projectName = "Store Power";

    $folderName = "project";

    $urlBase = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['SERVER_NAME']."/$folderName/";

    $pathName = $_SERVER['DOCUMENT_ROOT']."/$folderName";

    # EXIBE AS CONFIGURAÇÕES DO SERVIDOR    
    // echo "<pre>";
    //     print_r($_SERVER);
    // echo "<pre>";

?>